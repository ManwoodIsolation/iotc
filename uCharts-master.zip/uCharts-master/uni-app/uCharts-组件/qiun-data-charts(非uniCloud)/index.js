import qiunDataCharts from './components/qiun-data-charts/qiun-data-charts.vue'
export default qiunDataCharts;