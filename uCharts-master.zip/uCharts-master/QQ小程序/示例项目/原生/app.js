//app.js
App({
  onLaunch: function () {
    // 展示本地存储能力
  },
  globalData: {
    userInfo: null
  }
})
