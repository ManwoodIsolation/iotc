## 使用方法详见官网原生文档或在线演示中的代码

[https://www.ucharts.cn](https://www.ucharts.cn)

注：示例中uCharts仅做演示，实际使用请用码云或者npmjs中最新版本
