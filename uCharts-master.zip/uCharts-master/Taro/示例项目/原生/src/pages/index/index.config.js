export default {
  navigationBarTitleText: 'uCharts Demo'
}
