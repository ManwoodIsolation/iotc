Component({
  properties: {
    errorMessage: {
      type: String,
      value: null
    }
  },
  observers: {
    'errorMessage': function (val) {}
  },
  methods: {}
});